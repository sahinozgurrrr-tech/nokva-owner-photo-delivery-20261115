# NOKVA Balıkçı V61B | Profesyonel halo araştırması ve kaynak-kilitli test kaydı
Tarih: 15 Kasım 2026 | Kullanıcı isteği: **Imagine kullanma; fotoğraf V61B kalsın; yalnız kafa/yüz çevresinin hatalarını düzelt.**

## Kaynaklar (birebir gerçek Mac dosyaları)
- Kilitli başvuru: `30_V61_NO_HARD_LOWER_EDGE_20261115/IRFAN_FISH_V61B_VERTICAL_SKY_EDGE_FADE_QA_HOLD.png`, 554×554, SHA-256 `dfc15ce0d4135538f56db0ec8654bda9716c518b2e97f292be8e2a2795e99124`.
- Orijinal çekim: `~/TIGRE_BUILD_LAB/NOKVA_IRFAN_BALIK_20261114/00_ORIGINAL_LOCKED/BALIK_KAYNAK_02.jpg`.
- Oyuncu 2014 görünüm referansı: `~/TIGRE_BUILD_LAB/NOKVA_IRFAN_BALIK_20261114/01_ACTOR_REFS/Serkan_2014_ItirazimVar.jpg`; gerçek 620x462 JPEG, SHA-256 `f397bea02b4ef8f1ca8685c22f208bd80cd056985f7c1cf4028348b3a80648bb`.
- Kaynak yüzün eski landmark hizalaması: `~/TIGRE_BUILD_LAB/NOKVA_IRFAN_BALIK_20261114/06_HANDOFF/v35_actor40_true_face_tight_mask.py`. Bu hizalama bir bütün-fotoğraf değişimi için değil, yalnız yüz kenarı teşhisi için kullanıldı.
- Çalışılan ayırma maskesi: `28_V59_PROPER_FOREGROUND_MATTE_20261115/HEAD_GRABCUT_ERODE_0_MASK.png`.

## Araştırma: Profesyoneller bu hatayı nasıl ele alıyor?
1. Doğal kompozit sınırı salt binary GrabCut değil, saç/ten/gökyüzü için **fractional alpha matte** gerekir. Belge: MIT Computational Photography `https://people.csail.mit.edu/fredo/comp-photo-book/08-single-image-computational-photography-08-compositing-segmentation-and-matting.html`.
2. **Halo yalnız maske hatası değildir.** Ön plan renk çıkarımı gerekir; PyMatting belgeleri matting sonra doğrudan piksel çarpımının halo ürettiğini örnekle açıklar: `https://pymatting.github.io/`, `https://pymatting.github.io/foreground.html`.
3. Beyaz/renkli fringe için kenar renklerini gerçek ön plan renkleriyle decontaminate edip yeni maskede tutma; otomatik 2-4px maske daraltması saç/çeneyi kesebilir. Uygulama özeti: `https://layerbench.design/blog/how-to-defringe-in-photoshop-step-by-step-workflow-and-troubleshooting/`.
4. Matematiksel sınır: bir kez 554px JPG/PNG'ye gömülen saç alfası ve gökyüzü renk karışımını tek kanaldan kusursuz geri çıkarma her zaman mümkün değildir; orijinal alfa kaynak katmanı varsa en iyi sonuç onunla elde edilir. Kaynak: Levin vd. 2008 DOI 10.1109/TPAMI.2007.1177.

## Gerçekten uygulanan yöntemler (kayıtlı kod ve PNG'ler)
- `37_V68_CLOSED_FORM_MATTING_20261115`: **PyMatting 1.1.16** macOS venv'e ücretsiz kuruldu, kaynak maskeden trimap oluşturuldu, closed-form alfa + multilevel foreground extraction çalıştırıldı. V68A/B/C PNG ve tam kare/4x karşılaştırma oluşturuldu. Yüz merkezi ve tüm balık sahnesi RGB kilitli. **Bağımsız QA: V61B en güvenli, V68A/B/C halo sorununu belirgin çözmüyor, NO-GO.** `INDEPENDENT_V68_ACTUAL_PIXEL_QA.md` ile birlikte.
- `38_V69_2014_NATIVE_SOURCE_HAIR_20261115`: oyuncu 2014 gerçek ref yüzü beş noktalı V35 affine ile V61B'ye eşlendi, yalnız teşhis dosyaları. Kaynak fotoğrafın alın/saç tepesinin kadraj üstünden taşması nedeniyle `BORDER_REFLECT` sahte tekrar oluşturuyor; üst kafa çizgisi için bu warp doğrudan kullanılmamalı.
- `39_V70_2014_TRUE_SOURCE_EDGE_20261115`: Gerçek oyuncu kaynak JPEG'de GrabCut + PyMatting alfa/ön plan tahmini yapıldı, ardından V61B'nin yalnız sağ yanak/çene kontakt bölgesine kayıtlı kaynak renkleriyle yerel blend uygulandı. V70A/B/C 286/382/424 piksel değişimi; kilitli yüz merkezi ve tüm balık sahnesi korunuyor. 5x görselde değişiklik küçük; 8.5 puan ispatlanmadı.
- `40_V71_SUBPIXEL_SKY_FACE_FINAL_CANDIDATE_20261115`: V61B'yi tekrar doğrudan taban alan 0.35/0.65/1.05px içe kaydırılmış yumuşak-alfalı, **gerçek kaynak renkli**, gökyüzü ton gradyanlı lokal antialias seçenekleri A/B/C. Sadece sağ yanak ve çene çevresi, yüz merkezi/fotoğrafın kalanı kilitli. Native 5x `V71_V61B_NATIVE_5X_FACE_EDGE_QA.png`; bağımsız QA'ya gönderildi. **QA sonucu olmadan 8.5/9 GO denmeyecek.**

## Kalite kontrol ve dürüst karar
- Önceki V61B halen en az riskli referans: bağımsız denetimde bütün fotoğraf yaklaşık **7.0/10**, kafa kenarı **6.7/10**; bu puanlar öznel, biyometrik/insan sertifikasyonu değil.
- Önceki Poisson geniş sky patch, V63 inpaint, V67 mask shrink ve V68 PyMatting turları kenarı doğal göstermeyi başaramadı; **herhangi biri 8.5 diye teslim edilmeyecek**. V61B asla üzerine yazılmadı.
- 2014 kaynak kare daha büyük olsa bile alın/saç tepesinde doğal siluet kırpılmış; V61B'nin 554x554 birleşik fotoğrafında özgün alfa kanalı yok. Mevcut teknik verilerle 8.5'i garantilemek mümkün değil.
- Runway kredi harcaması: **0**. Imagine: **kullanılmadı**.

## Devamlılık ve teslim disiplini
Yeni QA görselini ayrı model/uzman 1x+native4/5x inceleyip önceki V61B ile kıyaslamalı. Eğer daha kötü/eşitse **V61B'yi koru, sahte finali yükleme**. Eğer belirgin daha iyiyse yalnız değiştirilmiş RGB pikselleri üstte ve kilitli V61B tabanı altta olacak şekilde katmanlı GIMP/ORA/XCF, SHA256 ve birebir PNG yayımla. Kullanıcı iPhone ChatGPT uygulamasında açabileceği doğrudan bağlantı bekliyor.
