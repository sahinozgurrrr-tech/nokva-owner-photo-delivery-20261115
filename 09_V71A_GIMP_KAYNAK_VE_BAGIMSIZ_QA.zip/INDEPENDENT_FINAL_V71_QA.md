# INDEPENDENT FINAL V71 PHOTO QA — 2026-11-15 (Europe/Istanbul)

## Decision

**NO-GO for customer delivery or a claimed 8.5–9/10 result.** **V61B remains the safest of the four actual PNGs reviewed.** V71A makes the most plausible *very small* local softening, but none of V71A/B/C meaningfully removes the visible pale edge along the image-right temple/cheek/jaw in a side-by-side five-times nearest-neighbor comparison. V71B/C also risk replacing the pale line with a thin dark or overly smooth contour. The new variants are too close to V61B at native resolution to justify promoting a version as a successful fix. This is the requested terminal independent review; **no additional iteration is recommended as part of this review**.

| Actual file | Whole-photo realism (/10) | Head-to-sky edge integration (/10) | Final judgment |
|---|---:|---:|---|
| **V61B** | **7.0** | **6.7** | **Best/safest retained baseline; still QA_HOLD, NO-GO** |
| V71A | 7.0 | 6.8 | Marginal local contact softening, visible pale line remains; no meaningful whole-photo gain |
| V71B | 6.9 | 6.7 | Slightly more forceful treatment creates a thin defined edge; not visibly superior |
| V71C | 6.9 | 6.6 | Highest risk of dark/slightly artificial contact edge, no convincing halo removal |

Scores are deliberately conservative independent visual estimates, not calibrated objective scores. **Confidence: high (0.9) that none meets 8.5/9 or fixes the user-visible issue; medium (0.65) on the subtle A/B/C relative ordering**, because only about 1,200–1,300 pixels differ and all four look nearly identical at 554 × 554.

## Inspection and visible defects

- Reviewed **actual native 554 × 554 images** `IRFAN_FISH_V61B_VERTICAL_SKY_EDGE_FADE_QA_HOLD.png`, `IRFAN_FISH_V71A/B/C_TRUE_SOFT_CONTACT_BLEND_QA_HOLD.png`, plus the true `V71_V61B_NATIVE_5X_FACE_EDGE_QA.png` four-column, nearest-neighbor 5× comparison. These are the existing original image files, not regenerated previews.
- At **full frame**, all four retain the same convincing fish, hands, clothing, lake and sky framing; the face/head junction is still the first place a careful viewer notices a composite. Changes introduced in V71 cannot be distinguished confidently without magnification.
- At **5×**, a light, sharply differentiated line persists beside the image-right temple, cheek and along the lower jaw toward the dark beard. A slightly bright edge on the hairline/ear region and the dark beard/neck boundary remain. On V71A this becomes microscopically softer in spots, but the full length of the offending line does **not** disappear. V71B/C are increasingly liable to make the boundary look like a dark stroke rather than a natural, irregular photographic edge.
- None introduces an obvious new large block, rectangular shoulder patch or major geometry shift. However, the skin/head is comparatively sharper and differently colored than the surrounding distant landscape and pale sky; the light contact seam remains visible at strong zoom. There is no basis to certify full photorealism or actor-source identity from this localized four-image test.
- `build_v71_source_photo_soft_contact.py` restricts its edits to the image-right silhouette over roughly y62–154 and asserts face core/scenery locks. Its own `V71_SOURCE_RGBA_LOCAL_QA.json` records `8_5_pass: false`. **Code assertions and recorded hashes do not constitute an independent proof of photographic naturalness.**

## Existing SHA-256 manifest (source-bound candidate identification)

The following full hashes are recorded in `V71_SOURCE_RGBA_LOCAL_QA.json`; this review read the actual images visually, but could not independently run a second terminal hash because the connected Mac terminal session limit was already reached. Thus these are explicitly **manifest-reported**, not independently rehashed, values:

| Input/candidate | SHA-256 |
|---|---|
| V61B original / V71 base | `dfc15ce0d4135538f56db0ec8654bda9716c518b2e97f292be8e2a2795e99124` |
| V71A | `991e0d444282c60e5258e6c5ba0610fc53de82e09c3be719128341cb81e30aba` |
| V71B | `3d36674db29da46a1450898cd99b6508cd65f0a6ae708a3bf86b596ede442b08` |
| V71C | `b29604c3871353f30402bf7d99d0240c8d184595fe73d001818e0c6d36d3f339` |

The V71 candidate manifest reports changed pixels A=1,215, B=1,307, C=1,284 relative to V61B. The existing `30_V61.../INDEPENDENT_V61_LAST_QA.md` separately classified V61B as **7.0 overall / 6.7 head edge**, provisional **NO-GO**, which aligns with this final independent pass.

**End-state:** Select **V61B** as the least-risk archival candidate; keep `QA_HOLD`. **None of V61B/V71A/V71B/V71C passes the user-required realistic edge / 9-point threshold.** Review only: no image edits, generation, upload or delivery performed.
