#!/usr/bin/env python3
"""V72: source-locked camera light-wrap + contact matte relighting.

V61B already has correct photographic identity and entire composition. Only
right temple/cheek/chin contact uses real same-photo sky light wrapping INTO
the 1-6px skin/beard side; 1-12px external ghost sky is decontaminated.
This is not repeated contour erosion or sky painting alone.
"""
from pathlib import Path
import cv2,numpy as np,json,hashlib
from scipy.ndimage import gaussian_filter1d

R=Path.home()/'TIGRE_BUILD_LAB/NOKVA_DUAL_PHOTO_FINAL_20261115'
W=R/'41_V72_CAMERA_LIGHTWRAP_EDGE_RELIGHT_20261115'
W.mkdir(exist_ok=True,parents=True)
SRC=R/'30_V61_NO_HARD_LOWER_EDGE_20261115/IRFAN_FISH_V61B_VERTICAL_SKY_EDGE_FADE_QA_HOLD.png'
M=R/'28_V59_PROPER_FOREGROUND_MATTE_20261115/HEAD_GRABCUT_ERODE_0_MASK.png'
im=cv2.imread(str(SRC))
mask=cv2.imread(str(M),0)
assert im.shape==(554,554,3)
raw=im.astype(np.float32)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
s=lambda t:np.clip(t,0,1)**2*(3-2*np.clip(t,0,1))
outline=[]
for y in range(52,155):
 pos=np.flatnonzero(mask[y,150:294]>0)+150
 if len(pos)==0:continue
 outline.append([y,int(pos.max())])
outline=np.asarray(outline)
xvals=gaussian_filter1d(outline[:,1].astype(float),1.3)
# Output 3 safe variants.
report={'source_sha256':sha(SRC),'method':'Interior camera sky light wrap and exterior fringe color decontamination, no image generation','variants':{},'QA':'PENDING'}
for label,wrap_peak,bgmax,edge_center in [('A',.075,.67,-.2),('B',.125,.82,-.45),('C',.165,.88,-.75)]:
 res=raw.copy()
 for idx,(y,r0) in enumerate(outline):
  r=float(xvals[idx]);rx=int(round(r))
  # 50px of real camera sky on same scanline for texture gradient.
  skypatch=raw[max(0,y-1):y+2,rx+23:rx+42]
  if not len(skypatch):continue
  sky=np.median(skypatch,axis=(0,1))
  # Use actual near-surface skin/beard (never black sideburn core).
  surface=np.median(raw[max(0,y-1):y+2,rx-4:rx-1],axis=(0,1))
  bright=np.clip(s((y-50)/11)*s((157-y)/16),0,1)
  for x in range(max(0,rx-8),min(554,rx+20)):
   d=x-r
   if d<-6.8:continue
   px=raw[y,x]
   if d<0:
    # Actual light spill from cloudy sky onto outer 6px skin/beard,
    # reaching zero 7px inward. Color retains original skin structure.
    t=np.exp(-(abs(d)/2.45)**1.35)
    w=bright*wrap_peak*t*s((d+7)/4)
    # Avoid washing hair texture by keeping 90% of native foreground.
    res[y,x]=px*(1-w)+sky*w
   elif d<=3.7:
    # camera edge alpha transition 1 at d~-2, zero near d+3.
    alpha=1-s((d-edge_center+1.6)/4.7)
    # Reference foreground is really from the camera image, blended with
    # observed edge color to avoid a dark/bright artificial stroke.
    fg=.60*surface+.40*px
    target=alpha*fg+(1-alpha)*sky
    # Do not 100% overwrite photo original aliased edge.
    w=bright*(.68+.23*bgmax)
    res[y,x]=px*(1-w)+target*w
   else:
    # decontaminate ONLY near sky. Never let a rectangular sky patch end.
    t=s((d-3.2)/3.1)*(1-s((d-11.8)/7.0))
    w=bright*bgmax*t
    # gradients preserve original cloud tonality where it is already sound
    donor=.78*sky+.22*raw[y,min(553,rx+34)]
    res[y,x]=px*(1-w)+donor*w
 result=np.uint8(np.clip(np.rint(res),0,255))
 assert np.array_equal(result[:50],im[:50])
 assert np.array_equal(result[155:],im[155:])
 assert np.array_equal(result[:,:160],im[:,:160])
 assert np.array_equal(result[:,320:],im[:,320:])
 assert np.array_equal(result[78:127,187:227],im[78:127,187:227])
 assert np.array_equal(result[275:],im[275:])
 p=W/f'IRFAN_FISH_V72{label}_REAL_CAMERA_LIGHTWRAP_QA_HOLD.png'
 assert not p.exists();cv2.imwrite(str(p),result)
 report['variants'][label]={'path':str(p),'sha256':sha(p),'changed_pixels':int(np.any(result!=im,axis=2).sum()),'body_face_core_fish_pixel_lock_pass':True}
# comparative contact 1x + 5x
for box,ratio,label in [((147,45,299,181),5,'FACE_EDGE_5X'),((130,20,316,207),3,'HEAD_NECK_3X')]:
 Wd=(box[2]-box[0])*ratio;Ht=(box[3]-box[1])*ratio
 canvas=np.full((Ht+32,Wd*4,3),247,np.uint8)
 for i,(title,p) in enumerate([('V61B',SRC)]+[(f'V72{k}',Path(report['variants'][k]['path'])) for k in 'ABC']):
  picture=cv2.imread(str(p))
  patch=cv2.resize(picture[box[1]:box[3],box[0]:box[2]],(Wd,Ht),interpolation=cv2.INTER_NEAREST)
  canvas[32:,i*Wd:(i+1)*Wd]=patch
  cv2.putText(canvas,title,(i*Wd+8,23),cv2.FONT_HERSHEY_SIMPLEX,.70,(6,6,6),1)
 cv2.imwrite(str(W/f'V72_{label}_NATIVE_COMPARE.png'),canvas)
(W/'V72_SOURCE_PIXEL_SHA_AUDIT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,indent=2,ensure_ascii=False),flush=True)

