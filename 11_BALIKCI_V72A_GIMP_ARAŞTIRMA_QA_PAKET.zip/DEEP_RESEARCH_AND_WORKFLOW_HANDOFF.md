# NOKVA Balıkçı V61B | 15 Kasım 2026 Son Kontrol & Mesleki Yöntem Testleri

## Kullanıcının kesin talimatı
- **V61B ana fotoğrafı korunacak.** Fotoğrafı sıfırdan üretme, Imagine kullanma.
- Mimik, oyuncu benzerliği, yüzün içi, kıyafet, balık, ağ, eller, su, gökyüzünün geri kalanı ve kadraj kilitli.
- Yalnız kafa çevresindeki fotoğraf montajı/white-gray fringe/çene çizgisi giderilecek.
- Bağımsız QA 8,5/10 doğrulamadan “9 puan finali” diye sunulmayacak.
- Her komut, test, kaynak SHA ve başarısız sürüm kaydedilecek.

## Doğrulanmış asıl kaynak
`30_V61_NO_HARD_LOWER_EDGE_20261115/IRFAN_FISH_V61B_VERTICAL_SKY_EDGE_FADE_QA_HOLD.png`
- 554 × 554 PNG
- SHA-256: `dfc15ce0d4135538f56db0ec8654bda9716c518b2e97f292be8e2a2795e99124`
- Orijinal fotoğraf: `~/TIGRE_BUILD_LAB/NOKVA_IRFAN_BALIK_20261114/00_ORIGINAL_LOCKED/BALIK_KAYNAK_02.jpg`
- Oyuncu kaynak portresi: `~/TIGRE_BUILD_LAB/NOKVA_IRFAN_BALIK_20261114/01_ACTOR_REFS/Serkan_2014_ItirazimVar.jpg` (fotoğrafın baş tepesi kısmen kadraj dışında).
- Head mask: `28_V59_PROPER_FOREGROUND_MATTE_20261115/HEAD_GRABCUT_ERODE_0_MASK.png`.

## Profesyonellerin aynı hata için önerdiği süreç
1. İyi matte alfa alanı ve geçiş bölgesini ayırmak, “sadece 1–4 px kontraksiyon” değil. Kaynak: `https://pymatting.github.io/`
2. Transparan alfa yanında **foreground color estimation/decontamination** uygulamak. Kaynak: `https://pymatting.github.io/foreground.html`.
3. Kaynak çekimin gerçek gökyüzünü clean-plate/arka plan olarak kullanmak, ışık/grain/PSF eşlemesini konturda ayrıca yapmak. Nuke user guide: `https://thefoundry.s3.amazonaws.com/products/nuke/documentation/NukeUserGuide_6.1v3.pdf`, spill removal bölümü.
4. Yüzün gerçek saç/sakal alfası önceki 554px düzleştirilmiş PNG'ye gömüldüğü için tek görüntüden yüzde yüz geri çıkarılmayabilir. Doğru orijinal alfa katmanı veya daha uygun çözünürlük ve açıdaki kaynak fotoğraf gerekebilir.

## Doğrudan V61B üzerinde uygulanan gerçek Mac işlemleri
- V62 gerçek çekim gökyüzünü geniş yaymalı inpaint: omuz/yaka üzerinde büyük hayalet lekeler, RED.
- V63 sağ dış gökyüzü-only inpaint: V63B gölge/ghost; C V61B'den belirgin üstün değil, RED.
- V64–V66 defringe, color spill, Poisson: beyaz/koyu çizgi kalıcı, RED.
- V67 2–4 px matte contraction: çene kenarında sert koyu çizgi, RED.
- V68 PyMatting **kuruldu** ve çalıştırıldı: closed-form alpha, trimap ve multi-level foreground estimation; üç gerçek kaynak kilitli PNG. Bağımsız gerçek 1×/4× inceleme **V61B'yi** seçti; halo çözülmedi.
- V69 2014 ref fotoğraf yüz hizalama: yalnız teşhis; saç tepesinde kaynak fotoğraf kadraj kesiliyor, warp bu bölgede doğal silueti geri getirmiyor.
- V70 yeni fotometrik kenar profili: kaynak yüz fotoğrafının gerçek yakın-yüz renklerinden ve gerçek gökyüzünden subpixel anti-alias/dar halo düzeltmesi; A/B/C ayrı. Bağımsız QA V70B'de **çok küçük yerel** yumuşama görüp 8,5 reddetti, V61B en güvenli.
- V71 farklı 2014 kaynak kenar soft contact seçenekleri: bağımsız QA V61B en güvenli, 8,5 reddedildi.
- V72 kamera-light-wrap (gökyüzünün yüzün dış 1–6px gölgesine etkisi) + dış contour renk temizliği; A/B/C ayrı ve 5x/3x native karşılaştırmalar; **QA raporu** `41_V72.../` klasöründe denetlenecek. V61B üzerine yazılmadı.
- Runway kredisi **0**, Imagine **yok**.

## Kalite ve dürüst karar
Kenarın yalnız beyaz pikselleri değil, eski yüz kaynak ışığı/gökyüzü tonuyla bütünleşmiş karışım ve düşük native çözünürlük esas engel. Bağımsız son doğrulanan V68/V70/V71 denemeleri yüksek kalitede net kazanım sağlamadı. 8,5–9 diye hiçbirisi satılmayacak. **En güvenli korunan V61B** (önceki bağımsız QA foto 7,0/10, kafa kenarı 6,7/10), ancak V72 bağımsız sonuçları kazanım doğrularsa o ayrı değerlendirmeye alınabilir.

## İşi tam bitirmek için gerekecek üretim kararı
İşe yarar alfa kaynak katmanı veya oyuncunun aynı açıya yakın, saç tepesini kesmeyen yüksek çözünürlüklü temiz kaynak fotoğrafıyla **sadece kafa dış temasını yeniden kurmak**; sonra Nuke/Fusion/GIMP selective decontaminate + gerçek kameranın sky/background clean plate + grain/blur/lighting match; eşik 8,5 gerçek insan incelemesiyle geçilirse teslim. Bu dosya çalışmanın bütün denemelerini ve neden reddedildiğini korur.

